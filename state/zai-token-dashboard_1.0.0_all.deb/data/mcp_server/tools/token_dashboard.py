#!/usr/bin/env python3
"""
Cline Token Dashboard — PyQt5 asztali alkalmazás.
Valós idejű token fogyasztás monitor, GPU/Qwen státusz, figyelmeztetések.

Optimális kontextus ablak számítás (Z.ai GLM-4.5, 128K context window):
  - Rendszer prompt + tools: ~15K
  - Használható társalgás: ~113K
  - FIGYELMEZTETÉS zóna: 100K (80%)
  - KRITIKUS zóna: 115K (90%)
  - Új task ajánlott: 120K felett
"""
import sys
import os
import re
import json
import glob
import time
import subprocess
from datetime import datetime, date
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QProgressBar, QFrame, QGridLayout, QPushButton,
    QSystemTrayIcon, QMenu, QAction, QMessageBox
)
from PyQt5.QtCore import QTimer, Qt, pyqtSignal
from PyQt5.QtGui import QFont, QColor, QPalette, QIcon

# ===========================================================================
# KONFIG
# ===========================================================================
CLINE_LOG_GLOB = "/home/Jules/.config/Code/logs/*/window*/exthost/output_logging_*/1-Cline.log"
TASK_HISTORY = "/home/Jules/.config/Code/User/globalStorage/saoudrizwan.claude-dev/state/taskHistory.json"

# Kontextus ablak limit (Z.ai GLM-4.5)
CONTEXT_WINDOW = 131072  # 128K
SYSTEM_OVERHEAD = 15360   # ~15K rendszer prompt + tools
USABLE_CONTEXT = CONTEXT_WINDOW - SYSTEM_OVERHEAD  # ~113K
WARN_THRESHOLD = int(USABLE_CONTEXT * 0.80)   # 90K
CRITICAL_THRESHOLD = int(USABLE_CONTEXT * 0.90)  # 102K
NEW_TASK_THRESHOLD = int(USABLE_CONTEXT * 0.95)  # 107K

# Kumulatív session limit (ajánlott max egy task-ban)
SESSION_WARN = 500_000     # 500K
SESSION_CRITICAL = 1_000_000  # 1M

# Ár modellek (Z.ai GLM-4.5 árazás, becslés)
COST_PER_1K_IN = 0.001
COST_PER_1K_OUT = 0.004

# Színek
COLOR_BG = "#1e1e2e"
COLOR_CARD = "#313244"
COLOR_TEXT = "#cdd6f4"
COLOR_GREEN = "#a6e3a1"
COLOR_YELLOW = "#f9e2af"
COLOR_RED = "#f38ba8"
COLOR_BLUE = "#89b4fa"
COLOR_PURPLE = "#cba6f7"
COLOR_TEAL = "#94e2d5"

USAGE_RE = re.compile(r'Task usage:.*?tokensIn=(\d+).*?tokensOut=(\d+).*?cost=([0-9.]+)')
INPUT_RE = re.compile(r'inputTokens=(\d+)')


def parse_logs():
    """Visszaadja az összes token adatot a Cline logokból."""
    entries = []
    latest_context = 0
    latest_cumulative = 0
    for lf in sorted(glob.glob(CLINE_LOG_GLOB)):
        try:
            with open(lf, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    m = USAGE_RE.search(line)
                    if m:
                        ts_match = re.match(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})', line)
                        ts = ts_match.group(1) if ts_match else "unknown"
                        entries.append({
                            "timestamp": ts,
                            "date": ts[:10],
                            "tokensIn": int(m.group(1)),
                            "tokensOut": int(m.group(2)),
                            "cost": float(m.group(3)),
                        })
                    m2 = INPUT_RE.search(line)
                    if m2:
                        val = int(m2.group(1))
                        if val < 200_000:
                            latest_context = val
                        elif val > latest_cumulative:
                            latest_cumulative = val
        except Exception:
            pass
    return entries, latest_context, latest_cumulative


def get_gpu_status():
    """P4000 GPU státusz."""
    try:
        r = subprocess.run(
            ['nvidia-smi', '--query-gpu=memory.used,memory.total,utilization.gpu,temperature.gpu',
             '--format=csv,noheader,nounits', '-i', '0'],
            capture_output=True, text=True, timeout=5
        )
        parts = r.stdout.strip().split(', ')
        return {
            'vram_used': int(parts[0]),
            'vram_total': int(parts[1]),
            'gpu_util': int(parts[2]),
            'temp': int(parts[3]),
        }
    except Exception:
        return None


def get_qwen_status():
    """MQL5 Qwen feldolgozás státusza a logból."""
    log_file = "/data/mcp_server/logs/mql5_book_qwen.log"
    try:
        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        phase = "?"
        current = 0
        total = 0
        last_tps = 0
        for line in lines:
            if "PHASE 1" in line:
                phase = "1: RAG"
            elif "PHASE 2" in line:
                phase = "2: Könyv"
            elif "PHASE 3" in line:
                phase = "3: Összegzés"
            m = re.search(r'\[(\d+)/(\d+)\]', line)
            if m:
                current = int(m.group(1))
                total = int(m.group(2))
            m2 = re.search(r'([\d.]+) tok/s', line)
            if m2:
                last_tps = float(m2.group(1))
        running = os.path.exists("/data/mcp_server/lock/mcp.lock")
        return {
            'phase': phase, 'current': current, 'total': total,
            'tps': last_tps, 'running': running,
        }
    except Exception:
        return None


class CardWidget(QFrame):
    """Egy kártya a dashboard-on."""
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.setFrameStyle(QFrame.StyledPanel)
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {COLOR_CARD};
                border-radius: 10px;
                border: 1px solid #45475a;
            }}
        """)
        self.layout_v = QVBoxLayout(self)
        self.layout_v.setContentsMargins(12, 8, 12, 8)
        self.layout_v.setSpacing(4)
        self.title_label = QLabel(title)
        self.title_label.setStyleSheet(f"color: {COLOR_TEXT}; font-size: 11px; font-weight: bold;")
        self.layout_v.addWidget(self.title_label)

    def add_label(self, text, color=COLOR_TEXT, size=14, bold=False):
        lbl = QLabel(text)
        weight = "bold" if bold else "normal"
        lbl.setStyleSheet(f"color: {color}; font-size: {size}px; font-weight: {weight};")
        self.layout_v.addWidget(lbl)
        return lbl

    def add_bar(self, value, maximum, color):
        bar = QProgressBar()
        bar.setMaximum(maximum)
        bar.setValue(value)
        bar.setTextVisible(True)
        bar.setFormat(f"{value:,} / {maximum:,}")
        bar.setStyleSheet(f"""
            QProgressBar {{
                background-color: #181825;
                border: 1px solid #45475a;
                border-radius: 5px;
                text-align: center;
                color: {COLOR_TEXT};
                font-size: 10px;
                height: 18px;
            }}
            QProgressBar::chunk {{
                background-color: {color};
                border-radius: 4px;
            }}
        """)
        self.layout_v.addWidget(bar)
        return bar


class DashboardWindow(QMainWindow):
    """Fő dashboard ablak."""
    def __init__(self, start_minimized=False):
        super().__init__()
        self.setWindowTitle("Z.ai Token Dashboard")
        self.setMinimumSize(700, 500)
        self.setStyleSheet(f"QMainWindow {{ background-color: {COLOR_BG}; }}")
        # Z.ai ikon beállítása
        icon_path = "/data/mcp_server/state/icons/zai-256.png"
        if os.path.isfile(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        self.tray = None
        self._start_minimized = start_minimized
        self._init_ui()
        self._init_tray()
        # Frissítési timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(5000)  # 5 másodpercenként
        self.refresh()
        # Ha minimalizálva indul, tálcára küldjük
        if start_minimized:
            self.hide()
            if self.tray:
                self.tray.show()
                self.tray.showMessage("Z.ai Dashboard", "Tálcán fut — kattints a megjelenítéshez", QSystemTrayIcon.Information)

    def _init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(8)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # Fejléc
        header = QLabel("  Z.ai TOKEN DASHBOARD")
        header.setStyleSheet(f"color: {COLOR_BLUE}; font-size: 18px; font-weight: bold; padding: 4px;")
        main_layout.addWidget(header)

        self.lbl_clock = QLabel("")
        self.lbl_clock.setStyleSheet(f"color: {COLOR_PURPLE}; font-size: 11px;")
        main_layout.addWidget(self.lbl_clock)

        # Kártyák rács
        grid = QGridLayout()
        grid.setSpacing(8)
        main_layout.addLayout(grid)

        # 1. Kontextus ablak kártya
        self.card_context = CardWidget("KONTEXTUS ABLAK (128K)")
        grid.addWidget(self.card_context, 0, 0)
        self.ctx_label = self.card_context.add_label("--", COLOR_GREEN, 20, bold=True)
        self.ctx_bar = self.card_context.add_bar(0, USABLE_CONTEXT, COLOR_GREEN)
        self.ctx_hint = self.card_context.add_label("", COLOR_TEXT, 10)

        # 2. Mai token kártya
        self.card_today = CardWidget("MAI TOKEN HASZNÁLAT")
        grid.addWidget(self.card_today, 0, 1)
        self.today_in = self.card_today.add_label("IN: --", COLOR_BLUE, 14, bold=True)
        self.today_out = self.card_today.add_label("OUT: --", COLOR_GREEN, 14, bold=True)
        self.today_cost = self.card_today.add_label("Költség: --", COLOR_YELLOW, 16, bold=True)
        self.today_calls = self.card_today.add_label("API hívások: --", COLOR_TEXT, 11)

        # 3. Kumulatív session kártya
        self.card_session = CardWidget("SESSION KUMULATÍV (inputTokens)")
        grid.addWidget(self.card_session, 1, 0)
        self.sess_label = self.card_session.add_label("--", COLOR_PURPLE, 18, bold=True)
        self.sess_bar = self.card_session.add_bar(0, SESSION_CRITICAL, COLOR_PURPLE)
        self.sess_hint = self.card_session.add_label("", COLOR_TEXT, 10)

        # 4. GPU + Qwen kártya
        self.card_gpu = CardWidget("P4000 GPU + QWEN MQL5")
        grid.addWidget(self.card_gpu, 1, 1)
        self.gpu_vram = self.card_gpu.add_label("VRAM: --", COLOR_TEAL, 13)
        self.gpu_util = self.card_gpu.add_label("GPU: --%", COLOR_GREEN, 13)
        self.gpu_temp = self.card_gpu.add_label("Temp: --°C", COLOR_TEXT, 12)
        self.qwen_status = self.card_gpu.add_label("Qwen: --", COLOR_BLUE, 12)
        self.qwen_tps = self.card_gpu.add_label("Speed: --", COLOR_TEXT, 12)

        # 5. Optimum kártya
        self.card_opt = CardWidget("OPTIMÁLIS TASK AJÁNLÁS")
        grid.addWidget(self.card_opt, 2, 0, 1, 2)
        self.opt_label = self.card_opt.add_label("--", COLOR_TEAL, 13)

        # Figyelmeztetés sáv
        self.warn_label = QLabel("")
        self.warn_label.setStyleSheet(f"""
            QLabel {{
                background-color: {COLOR_CARD};
                border-radius: 6px;
                border: 1px solid #45475a;
                padding: 6px;
                font-size: 13px;
                font-weight: bold;
            }}
        """)
        self.warn_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(self.warn_label)

        # Gombok
        btn_layout = QHBoxLayout()
        self.btn_pause = QPushButton("GPU Pause")
        self.btn_resume = QPushButton("GPU Resume")
        self.btn_refresh = QPushButton("Frissítés")
        for b in [self.btn_pause, self.btn_resume, self.btn_refresh]:
            b.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLOR_CARD};
                    color: {COLOR_TEXT};
                    border: 1px solid #45475a;
                    border-radius: 6px;
                    padding: 6px 16px;
                    font-size: 12px;
                }}
                QPushButton:hover {{ background-color: #45475a; }}
            """)
        self.btn_pause.clicked.connect(lambda: os.system("/data/mcp_server/tools/gpu_pause.sh"))
        self.btn_resume.clicked.connect(lambda: os.system("/data/mcp_server/tools/gpu_resume.sh"))
        self.btn_refresh.clicked.connect(self.refresh)
        btn_layout.addWidget(self.btn_pause)
        btn_layout.addWidget(self.btn_resume)
        btn_layout.addWidget(self.btn_refresh)
        main_layout.addLayout(btn_layout)

    def _init_tray(self):
        self.tray = QSystemTrayIcon(self)
        # Z.ai ikon a tálcára
        icon_path = "/data/mcp_server/state/icons/zai-48.png"
        if os.path.isfile(icon_path):
            self.tray.setIcon(QIcon(icon_path))
        self.tray.setToolTip("Z.ai Token Dashboard")
        menu = QMenu()
        act_show = QAction("Megjelenítés", self)
        act_show.triggered.connect(self.showNormal)
        act_hide = QAction("Elrejtés a tálcára", self)
        act_hide.triggered.connect(self.hide)
        act_refresh = QAction("Frissítés", self)
        act_refresh.triggered.connect(self.refresh)
        act_quit = QAction("Kilépés", self)
        act_quit.triggered.connect(self.close)
        menu.addAction(act_show)
        menu.addAction(act_hide)
        menu.addSeparator()
        menu.addAction(act_refresh)
        menu.addSeparator()
        menu.addAction(act_quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()

    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.DoubleClick:
            self.showNormal()
            self.activateWindow()
            self.raise_()

    def closeEvent(self, event):
        """Bezúrás: tálcára rejtés, nem kilépés (ha tray aktív)."""
        if self.tray and self.tray.isVisible():
            event.ignore()
            self.hide()
            self.tray.showMessage("Z.ai Dashboard", "Tálcára minimalizálva — dupla kattintás a megjelenítéshez", QSystemTrayIcon.Information)
        else:
            event.accept()

    def refresh(self):
        """Adatok frissítése 5s-enként."""
        entries, ctx_tokens, sess_cumul = parse_logs()
        now = datetime.now()
        self.lbl_clock.setText(f"Frissítve: {now.strftime('%Y-%m-%d %H:%M:%S')}")

        # --- Kontextus ablak ---
        if ctx_tokens > 0:
            pct = ctx_tokens / USABLE_CONTEXT * 100
            if pct < 80:
                color = COLOR_GREEN
            elif pct < 90:
                color = COLOR_YELLOW
            else:
                color = COLOR_RED
            self.ctx_label.setText(f"{ctx_tokens:,} token ({pct:.0f}%)")
            self.ctx_label.setStyleSheet(f"color: {color}; font-size: 20px; font-weight: bold;")
            self.ctx_bar.setMaximum(USABLE_CONTEXT)
            self.ctx_bar.setValue(ctx_tokens)
            if pct >= 95:
                self.ctx_hint.setText("ÚJ TASK AJÁNLÁSA — kontextus közel tele")
                self.ctx_hint.setStyleSheet(f"color: {COLOR_RED}; font-size: 10px;")
            elif pct >= 80:
                self.ctx_hint.setText("FIGYELMEZTETÉS — kontextus 80% felett")
                self.ctx_hint.setStyleSheet(f"color: {COLOR_YELLOW}; font-size: 10px;")
            else:
                self.ctx_hint.setText(f"Kényelmes tartomány (limit: {WARN_THRESHOLD:,})")
                self.ctx_hint.setStyleSheet(f"color: {COLOR_TEXT}; font-size: 10px;")
        else:
            self.ctx_label.setText("Nincs aktív task")

        # --- Mai tokenek ---
        today_str = date.today().isoformat()
        today_entries = [e for e in entries if e["date"] == today_str]
        tin = sum(e["tokensIn"] for e in today_entries)
        tout = sum(e["tokensOut"] for e in today_entries)
        cost = sum(e["cost"] for e in today_entries)
        calls = len(today_entries)
        self.today_in.setText(f"IN: {tin:,} ({tin/1000:.1f}K)")
        self.today_out.setText(f"OUT: {tout:,} ({tout/1000:.1f}K)")
        self.today_cost.setText(f"Költség: ${cost:.4f}")
        self.today_calls.setText(f"API hivasok: {calls}")

        # --- Kumulatív session ---
        if sess_cumul > 0:
            self.sess_label.setText(f"{sess_cumul:,} ({sess_cumul/1_000_000:.2f}M)")
            self.sess_bar.setValue(min(sess_cumul, SESSION_CRITICAL))
            if sess_cumul > SESSION_CRITICAL:
                self.sess_hint.setText("KRITIKUS — nagyon hosszú session!")
                self.sess_hint.setStyleSheet(f"color: {COLOR_RED}; font-size: 10px;")
            elif sess_cumul > SESSION_WARN:
                self.sess_hint.setText("FIGYELMEZTETÉS — hosszú session")
                self.sess_hint.setStyleSheet(f"color: {COLOR_YELLOW}; font-size: 10px;")
            else:
                self.sess_hint.setText(f"Rendben (warn: {SESSION_WARN:,})")
                self.sess_hint.setStyleSheet(f"color: {COLOR_TEXT}; font-size: 10px;")

        # --- GPU ---
        gpu = get_gpu_status()
        if gpu:
            self.gpu_vram.setText(f"VRAM: {gpu['vram_used']}/{gpu['vram_total']} MB ({gpu['vram_used']/gpu['vram_total']*100:.0f}%)")
            self.gpu_util.setText(f"GPU: {gpu['gpu_util']}%")
            self.gpu_temp.setText(f"Temp: {gpu['temp']}C")
            uc = COLOR_GREEN if gpu['gpu_util'] < 60 else (COLOR_YELLOW if gpu['gpu_util'] < 80 else COLOR_RED)
            self.gpu_util.setStyleSheet(f"color: {uc}; font-size: 13px;")

        # --- Qwen MQL5 ---
        qwen = get_qwen_status()
        if qwen:
            status = "FUT" if qwen['running'] else "ALL"
            self.qwen_status.setText(f"Qwen 14B: {status} | Phase {qwen['phase']}")
            if qwen['total'] > 0:
                self.qwen_tps.setText(f"Haladas: {qwen['current']}/{qwen['total']} | {qwen['tps']:.1f} tok/s")
            else:
                self.qwen_tps.setText(f"Sebesseg: {qwen['tps']:.1f} tok/s")

        # --- Optimális task ajánlás ---
        if ctx_tokens > 0:
            remaining = USABLE_CONTEXT - ctx_tokens
            avg_per_turn = 5000
            turns_left = remaining // avg_per_turn if avg_per_turn > 0 else 0
            tip = "INDITS UJ TASK-OT!" if turns_left < 5 else "meg van tartalek"
            self.opt_label.setText(
                f"Kontextus: {ctx_tokens/1000:.0f}K / {USABLE_CONTEXT/1000:.0f}K | "
                f"Hatralevo: ~{turns_left} kor ({remaining/1000:.0f}K) | Tipp: {tip}"
            )
        else:
            self.opt_label.setText("Nincs aktiv Cline task — indits egy feladatot a VS Code-ban")

        # --- Figyelmeztetés sáv ---
        if ctx_tokens > NEW_TASK_THRESHOLD:
            self.warn_label.setText("!!  KRITIKUS: Kontextus 95% felett! INDITS UJ TASK-OT!")
            self.warn_label.setStyleSheet(f"background-color: {COLOR_RED}; color: white; border-radius: 6px; padding: 6px; font-size: 13px; font-weight: bold;")
            if self.tray:
                self.tray.showMessage("Cline Dashboard", "KRITIKUS: Uj task szukseges!", QSystemTrayIcon.Critical)
        elif ctx_tokens > CRITICAL_THRESHOLD:
            self.warn_label.setText("!!  FIGYELMEZTETES: Kontextus 90% felett")
            self.warn_label.setStyleSheet(f"background-color: {COLOR_YELLOW}; color: black; border-radius: 6px; padding: 6px; font-size: 13px; font-weight: bold;")
        elif ctx_tokens > WARN_THRESHOLD:
            self.warn_label.setText(f"!!  Kontextus 80% ({ctx_tokens/1000:.0f}K) — figyeld a tokeneket!")
            self.warn_label.setStyleSheet(f"background-color: {COLOR_YELLOW}; color: black; border-radius: 6px; padding: 6px; font-size: 13px;")
        else:
            txt = f"OK — kontextus {ctx_tokens/1000:.0f}K / {USABLE_CONTEXT/1000:.0f}K" if ctx_tokens > 0 else "OK — Nincs aktiv task"
            self.warn_label.setText(txt)
            self.warn_label.setStyleSheet(f"background-color: {COLOR_GREEN}; color: black; border-radius: 6px; padding: 6px; font-size: 13px;")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Z.ai Token Dashboard")
    parser.add_argument("--minimized", action="store_true", help="Indítás tálcán (minimalizálva)")
    args = parser.parse_args()

    app = QApplication(sys.argv)
    app.setApplicationName("Z.ai Token Dashboard")
    # Z.ai ikon az alkalmazásnak
    icon_path = "/data/mcp_server/state/icons/zai-256.png"
    if os.path.isfile(icon_path):
        app.setWindowIcon(QIcon(icon_path))
    # Ellenőrizzük, hogy a tray elérhető-e
    if not QSystemTrayIcon.isSystemTrayAvailable():
        print("Figyelem: rendszertálca nem elérhető — ablak módban indul.")
        args.minimized = False
    window = DashboardWindow(start_minimized=args.minimized)
    if not args.minimized:
        window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
