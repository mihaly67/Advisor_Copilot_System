#!/bin/bash
# GPU pause — Qwen feldolgozás szünetelése
# Használat: ha GPU kell más feladatra (pl. MCTS benchmark, stress test)
# A futó Qwen batch a következő lekérdezésnél várakozik.
PAUSE_FILE="/data/mcp_server/lock/qwen_gpu_paused.flag"
mkdir -p "$(dirname "$PAUSE_FILE")"
touch "$PAUSE_FILE"
echo "⏸️  GPU pause aktív — Qwen feldolgozás szünetel."
echo "   Flag: $PAUSE_FILE"
echo "   Folytatáshoz: gpu_resume.sh"
