#!/usr/bin/env python3
"""
Cline Token Szamlalo — Vizualizalja a token fogyasztast es koltseget.
Olvassa a VS Code Cline log fajlokat es aggregalja az adatokat.

Hasznalat:
    python3 /data/mcp_server/tools/token_counter.py              # Osszes session
    python3 /data/mcp_server/tools/token_counter.py --today      # Csak mai
    python3 /data/mcp_server/tools/token_counter.py --watch      # Elo figyeles (5s-enkent)
    python3 /data/mcp_server/tools/token_counter.py --warn 4000   # Figyelmeztet 4000 token felett
"""
import os, re, sys, time, json, glob, argparse
from datetime import datetime, date

CLINE_LOG_GLOB = "/home/Jules/.config/Code/logs/*/window*/exthost/output_logging_*/1-Cline.log"
TASK_HISTORY = "/home/Jules/.config/Code/User/globalStorage/saoudrizwan.claude-dev/state/taskHistory.json"

USAGE_RE = re.compile(r'Task usage:.*?tokensIn=(\d+).*?tokensOut=(\d+).*?cost=([0-9.]+)')


def find_log_files():
    return sorted(glob.glob(CLINE_LOG_GLOB))


def parse_log_file(filepath):
    entries = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                m = USAGE_RE.search(line)
                if m:
                    ts_match = re.match(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})', line)
                    ts = ts_match.group(1) if ts_match else "unknown"
                    entries.append({
                        "timestamp": ts,
                        "date": ts[:10],
                        "tokensIn": int(m.group(1)),
                        "tokensOut": int(m.group(2)),
                        "cost": float(m.group(3)),
                    })
    except Exception as e:
        print(f"Hiba {filepath}: {e}", file=sys.stderr)
    return entries


def aggregate_entries(entries):
    agg = {}
    for e in entries:
        key = e["date"]
        if key not in agg:
            agg[key] = {"date": key, "api_calls": 0, "tokensIn": 0,
                        "tokensOut": 0, "cost": 0.0,
                        "first_ts": e["timestamp"], "last_ts": e["timestamp"]}
        agg[key]["api_calls"] += 1
        agg[key]["tokensIn"] += e["tokensIn"]
        agg[key]["tokensOut"] += e["tokensOut"]
        agg[key]["cost"] += e["cost"]
        agg[key]["last_ts"] = e["timestamp"]
    return agg


def format_num(n):
    return f"{n:,}".replace(",", " ")


def print_report(today_only=False):
    log_files = find_log_files()
    all_entries = []
    for lf in log_files:
        all_entries.extend(parse_log_file(lf))

    if not all_entries:
        print("Nem talalhato token adat a Cline logokban.")
        return 0, 0.0

    agg = aggregate_entries(all_entries)
    today_str = date.today().isoformat()

    if today_only:
        agg = {k: v for k, v in agg.items() if k == today_str}

    print("=" * 72)
    print("  CLINE TOKEN HASZNALATI JELENTES")
    print("=" * 72)
    print()
    print(f"{'Datum':<14} {'API hivas':<10} {'Token IN':<14} {'Token OUT':<14} {'Kolts ($)':<12}")
    print("-" * 72)

    total_in = total_out = total_cost = total_calls = 0
    for d in sorted(agg.keys()):
        a = agg[d]
        marker = " <- MA" if d == today_str else ""
        print(f"{a['date']:<14} {a['api_calls']:<10} {format_num(a['tokensIn']):<14} {format_num(a['tokensOut']):<14} ${a['cost']:<11.4f}{marker}")
        total_in += a["tokensIn"]
        total_out += a["tokensOut"]
        total_cost += a["cost"]
        total_calls += a["api_calls"]

    print("-" * 72)
    print(f"{'OSSZESEN':<14} {total_calls:<10} {format_num(total_in):<14} {format_num(total_out):<14} ${total_cost:<11.4f}")
    print()
    total_tokens = total_in + total_out
    print(f"  Osszes token (in+out): {format_num(total_tokens)}")
    print(f"  Osszes kolts:          ${total_cost:.4f}")
    if total_calls > 0:
        print(f"  Atlag token IN/keres:  {format_num(total_in // total_calls)}")
    print()

    if today_str in agg:
        t = agg[today_str]
        print(f"  MAI hasznalat ({today_str}):")
        print(f"    API hivasok: {t['api_calls']}")
        print(f"    Token IN:    {format_num(t['tokensIn'])}")
        print(f"    Token OUT:   {format_num(t['tokensOut'])}")
        print(f"    Kolts:       ${t['cost']:.4f}")
        print(f"    Elso hivas:  {t['first_ts']}")
        print(f"    Utolso:      {t['last_ts']}")

    return total_tokens, total_cost


def watch_mode(warn_limit=0):
    try:
        while True:
            os.system("clear" if os.name != "nt" else "cls")
            print(f"  CLINE TOKEN MONITOR - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            total_tokens, total_cost = print_report(today_only=False)

            if warn_limit > 0 and total_tokens > warn_limit:
                print()
                print(f"  !! FIGYELMEZTETES: {format_num(total_tokens)} token > {format_num(warn_limit)} limit!")
                print(f"     Erdemes uj taskot inditani a kontextus ablak csokkentesehez.")

            print()
            print("Frissites 5s mulva... (Ctrl+C kilp)")
            time.sleep(5)
    except KeyboardInterrupt:
        print("\nMonitor leallitva.")


def main():
    parser = argparse.ArgumentParser(description="Cline Token Szamlalo")
    parser.add_argument("--today", action="store_true", help="Csak mai adatok")
    parser.add_argument("--watch", action="store_true", help="Elo figyeles (5s frissites)")
    parser.add_argument("--warn", type=int, default=0, help="Figyelmeztetes ezen token felett")
    args = parser.parse_args()

    if args.watch:
        watch_mode(args.warn)
    else:
        print_report(today_only=args.today)


if __name__ == "__main__":
    main()
