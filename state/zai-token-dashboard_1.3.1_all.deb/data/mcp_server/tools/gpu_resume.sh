#!/bin/bash
# GPU resume — Qwen feldolgozás folytatása
PAUSE_FILE="/data/mcp_server/lock/qwen_gpu_paused.flag"
if [ -f "$PAUSE_FILE" ]; then
    rm -f "$PAUSE_FILE"
    echo "▶️  GPU pause feloldva — Qwen feldolgozás folytatódik."
else
    echo "✅ Nem volt pause flag aktív — Qwen megy tovább."
fi
